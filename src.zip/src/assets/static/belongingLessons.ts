

export const belongingLessons = [
  { label: 'ජීව විද්‍යාව හදුන්වා දීම', value: 'l1' },
  { label: 'ජීවයේ රසායනික හා සෛලීය පදනම', value: 'l2' },
  { label: 'පරිණාමය හා ජීවීන්ගේ විවිධත්වය', value: 'l3' },
  { label: 'ශාක ආකාරය හා ක්‍රියාකාරීත්වය', value: 'l4' },
  { label: 'සත්ත්ව ආකාරය හා ක්‍රියාකාරීත්වය - 1 කොටස', value: 'l5' },
  { label: 'සත්ත්ව ආකාරය හා ක්‍රියාකාරීත්වය - 2 කොටස', value: 'l6' },
  { label: 'ප්‍රවේණිය', value: 'l7' },
  { label: 'පාරිසරික ජීව විද්‍යාව', value: 'l8' },
  { label: 'ක්ෂුද්‍ර ජීව විද්‍යාව', value: 'l9' },
  { label: 'ව්‍යවහාරික ජීව විද්‍යාව', value: 'l10' },
  { label: 'Paper writting', value: 'l11' },
  { label: 'Other', value: 'l12' }
];
