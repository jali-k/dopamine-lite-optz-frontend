export const DopamineLiteColors = {
  creamColor: "#FFFBE6",
  greenColor: "#00712D",
  lightGreenColor: "#D5ED9F",
  orangeColor: "#FF9100"
};