
export interface MonthDetails {
  id: string;
  name: string;
  accessList: string[];
}