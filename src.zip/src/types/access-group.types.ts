export interface AccessGroup {
  id: string;
  name: string;
  accessList: string[];
}